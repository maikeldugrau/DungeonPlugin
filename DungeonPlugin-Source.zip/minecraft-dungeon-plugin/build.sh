#!/bin/bash
# Script de build para DungeonPlugin

echo "=================================="
echo "  Building DungeonPlugin v1.0.0"
echo "=================================="
echo ""

# Verificar se Maven está instalado
if ! command -v mvn &> /dev/null; then
    echo "❌ Maven não está instalado!"
    echo "Instale Maven primeiro: apt-get install maven"
    exit 1
fi

echo "✅ Maven encontrado"
echo ""

# Limpar builds anteriores
echo "🧹 Limpando builds anteriores..."
mvn clean

echo ""
echo "🔨 Compilando plugin..."
mvn package

echo ""
if [ -f "target/DungeonPlugin-1.0.0.jar" ]; then
    echo "=================================="
    echo "✅ BUILD CONCLUÍDO COM SUCESSO!"
    echo "=================================="
    echo ""
    echo "📦 Plugin compilado em:"
    echo "   target/DungeonPlugin-1.0.0.jar"
    echo ""
    echo "📋 Próximos passos:"
    echo "   1. Copie o JAR para a pasta plugins/ do servidor"
    echo "   2. Reinicie o servidor Minecraft"
    echo "   3. Configure em plugins/DungeonPlugin/config.yml"
    echo ""
else
    echo "=================================="
    echo "❌ ERRO NO BUILD!"
    echo "=================================="
    echo ""
    echo "Verifique os erros acima"
    exit 1
fi
