# 🏰 DungeonPlugin para Minecraft 1.21.10

## 📋 Descrição

Plugin de geração procedural de dungeons completas no Overworld do Minecraft 1.21.10. Cria dungeons de tamanho médio e grande com frequência rara, contendo:

- ✨ **3 Tipos de Dungeons:** Medieval, Mística e Subterrânea
- 🎯 **Conteúdo Completo:** Baús, Spawners, Armadilhas, Puzzles e Bosses
- 🎲 **Geração Procedural:** Cada dungeon é única
- 👑 **Bosses Customizados:** 3 tipos de chefes com mecânicas únicas
- 💎 **Loot Valioso:** Recompensas progressivas e tesouros raros

## 🎮 Tipos de Dungeons

### 1. Dungeon Medieval 🏰
- **Estilo:** Pedra, tijolos, tochas
- **Boss:** Cavaleiro das Trevas
- **Mobs:** Esqueletos e Guardiões
- **Estrutura:** Salas conectadas por corredores
- **Especial:** Pilares decorativos e sala do boss com 4 pilares

### 2. Dungeon Mística 🔮
- **Estilo:** Prismarine, obsidiana, cristais
- **Boss:** Feiticeiro Ancestre
- **Mobs:** Endermans, Vexes, Bruxas
- **Estrutura:** Salas em círculo ao redor de torre central
- **Especial:** Sala do boss elevada com altar e beacon

### 3. Dungeon Subterrânea ⛏️
- **Estilo:** Deepslate, cavernas naturais, minérios
- **Boss:** Golem das Cavernas
- **Mobs:** Zumbis, Aranhas, Esqueletos montados
- **Estrutura:** Sistema de túneis e cavernas
- **Especial:** Lago de lava, trilhos de minecart, cristais raros

## 📦 Instalação

### Pré-requisitos
- Servidor Spigot/Paper 1.21.10 ou superior
- Java 21+
- Maven (para compilar)

### Compilação

```bash
cd /app/minecraft-dungeon-plugin
mvn clean package
```

O arquivo JAR compilado estará em `target/DungeonPlugin-1.0.0.jar`

### Instalação no Servidor

1. Copie o arquivo JAR para a pasta `plugins/` do seu servidor
2. Reinicie o servidor
3. Configure o plugin em `plugins/DungeonPlugin/config.yml`
4. Use `/dungeon reload` para recarregar a configuração

## 🎯 Comandos

| Comando | Descrição | Permissão |
|---------|------------|------------|
| `/dungeon create` | Gera uma dungeon na sua localização | `dungeon.admin` |
| `/dungeon list` | Lista todas as dungeons geradas | `dungeon.admin` |
| `/dungeon info` | Mostra informações do plugin | `dungeon.admin` |
| `/dungeon reload` | Recarrega a configuração | `dungeon.admin` |

**Aliases:** `/dg`, `/dungeons`

## ⚙️ Configuração

Edite o arquivo `config.yml` para personalizar:

```yaml
generation:
  enabled: true
  rarity: 700  # 1 em 700 chunks (ajuste para mais/menos frequente)
  min-height: 10
  max-height: 50

dungeon-types:
  medieval:
    enabled: true
    weight: 33  # Probabilidade relativa
  mystic:
    enabled: true
    weight: 33
  underground:
    enabled: true
    weight: 34

sizes:
  medium:
    chance: 50  # 50% médio
  large:
    chance: 50  # 50% grande
```

## 🎁 Sistema de Loot

### Baús Normais
- Ferro, ouro, diamantes
- Comida e flechas
- Equipamentos básicos

### Baús de Boss
- Espadas e armaduras encantadas (Diamante/Netherite)
- Golden Apples e Totem of Undying
- Nether Star
- Experiência em garrafas
- Chance de Netherite Ingots

### Loot Específico por Tipo
- **Medieval:** Armas, armaduras, esmeraldas
- **Místico:** Ender pearls, livros encantados, cristais
- **Subterrâneo:** Minérios raros, ferramentas, recursos

## 👾 Bosses

### Cavaleiro das Trevas (Medieval)
- **Vida:** 200 HP
- **Equipamento:** Armadura e espada de Netherite encantadas
- **Habilidades:** Alta resistência, resistência ao fogo
- **Servos:** 2 Guardiões esqueletos

### Feiticeiro Ancestre (Místico)
- **Vida:** 180 HP
- **Tipo:** Bruxa aprimorada
- **Habilidades:** Regeneração, velocidade, resistência
- **Servos:** 3 Endermans e 4 Vexes

### Golem das Cavernas (Subterrâneo)
- **Vida:** 250 HP
- **Tipo:** Iron Golem aprimorado
- **Habilidades:** Resistência massiva, knockback immunity
- **Servos:** 4 Aranhas (algumas com esqueletos montados) e 3 Zumbis mineiros

## 🔧 Recursos Técnicos

### Geração Assíncrona
- Dungeons são geradas com delay para não travar o servidor
- Sistema otimizado para grandes estruturas

### Persistência
- Localizações de dungeons são rastreadas
- Evita geração duplicada no mesmo chunk

### Compatiblidade
- Suporta qualquer plugin de proteção (WorldGuard, GriefPrevention)
- Respects game rules e configurações de mundo

## 🐛 Resolução de Problemas

### Dungeons não estão gerando
1. Verifique se `generation.enabled: true` no config.yml
2. Aumente a frequência (diminua o valor de `rarity`)
3. Verifique os logs do servidor para erros

### Lag durante geração
1. Dungeons são geradas com delay automático
2. Considere aumentar o valor de `rarity` para menos dungeons

### Boss muito fácil/difícil
- Modifique os valores de HP e dano no código fonte (BossManager.java)
- Ajuste `loot-multiplier` para recompensar adequadamente

## 📝 Licença

Este plugin é open source e pode ser modificado livremente.

## 🤝 Contribuições

Sugestões e melhorias são bem-vindas!

## 📧 Suporte

Para bugs e sugestões, abra uma issue ou entre em contato.

---

**Versão:** 1.0.0  
**Minecraft:** 1.21.10  
**API:** Spigot/Paper  
**Java:** 21+
