# 📥 Como Baixar o Plugin DungeonPlugin

## 🎯 Método 1: Compilar Aqui e Baixar o JAR

### Passo 1: Compilar o Plugin
```bash
cd /app/minecraft-dungeon-plugin
./build.sh
```

### Passo 2: O JAR estará em:
```
/app/minecraft-dungeon-plugin/target/DungeonPlugin-1.0.0.jar
```

### Passo 3: Baixar o arquivo
- **Se estiver usando interface web:** Navegue até a pasta target/ e baixe o arquivo .jar
- **Se estiver usando SSH/terminal:** Use SCP ou SFTP para transferir

---

## 🎯 Método 2: Baixar Todo o Código Fonte

### Opção A - Criar arquivo ZIP
```bash
cd /app
zip -r minecraft-dungeon-plugin.zip minecraft-dungeon-plugin/
```

Depois baixe o arquivo: `/app/minecraft-dungeon-plugin.zip`

### Opção B - Clonar via Git (se disponível)
```bash
# Se o projeto tiver repositório Git
git clone [url-do-repositorio]
```

---

## 🎯 Método 3: Copiar Arquivos Individuais

Você pode copiar os arquivos manualmente:

### Arquivos Essenciais:
```
minecraft-dungeon-plugin/
├── pom.xml
├── src/main/java/com/dungeon/plugin/... (todos os .java)
└── src/main/resources/... (plugin.yml, config.yml)
```

---

## 💻 Compilar na Sua Máquina

### Pré-requisitos:
- Java 21+
- Maven 3.6+

### Comandos:
```bash
cd minecraft-dungeon-plugin
mvn clean package
```

O JAR será gerado em: `target/DungeonPlugin-1.0.0.jar`

---

## 📦 Instalar no Servidor Minecraft

1. Copie `DungeonPlugin-1.0.0.jar` para `servidor/plugins/`
2. Reinicie o servidor
3. Configure em `plugins/DungeonPlugin/config.yml`
4. Use `/dungeon info` para verificar

