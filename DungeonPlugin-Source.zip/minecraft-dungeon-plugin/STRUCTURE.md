# 📁 Estrutura do Projeto DungeonPlugin

## 🗂️ Organização de Arquivos

```
minecraft-dungeon-plugin/
│
├── 📄 pom.xml                      # Configuração Maven
├── 📄 README.md                    # Documentação completa
├── 📄 QUICKSTART.md               # Guia de início rápido
├── 📄 STRUCTURE.md                # Este arquivo
├── 🔧 build.sh                    # Script de build
│
└── src/main/
    │
    ├── java/com/dungeon/plugin/
    │   │
    │   ├── 🎯 DungeonPlugin.java           # Classe principal do plugin
    │   │
    │   ├── generator/                       # Sistema de geração
    │   │   ├── DungeonGenerator.java       # Controlador de geração
    │   │   ├── RoomGenerator.java          # Gerador de salas
    │   │   └── StructureBuilder.java       # Construtor de estruturas
    │   │
    │   ├── types/                          # Tipos de dungeons
    │   │   ├── MedievalDungeon.java       # Dungeon Medieval
    │   │   ├── MysticDungeon.java         # Dungeon Mística
    │   │   └── UndergroundDungeon.java    # Dungeon Subterrânea
    │   │
    │   ├── content/                        # Gerenciadores de conteúdo
    │   │   ├── LootManager.java           # Sistema de loot e baús
    │   │   ├── TrapManager.java           # Sistema de armadilhas
    │   │   ├── PuzzleManager.java         # Sistema de puzzles
    │   │   └── BossManager.java           # Sistema de bosses
    │   │
    │   ├── commands/                       # Comandos administrativos
    │   │   └── DungeonCommand.java        # /dungeon
    │   │
    │   └── listeners/                      # Event listeners
    │       └── ChunkListener.java         # Geração em chunks
    │
    └── resources/
        ├── 📄 plugin.yml                   # Metadata do plugin
        └── 📄 config.yml                   # Configuração padrão
```

---

## 🎨 Arquitetura do Sistema

### 🏗️ Camada de Geração (generator/)

**DungeonGenerator.java**
- Controlador principal de geração
- Decide quando e onde gerar dungeons
- Frequência: 1 em 700 chunks (raro)
- Escolhe tipo aleatório (Medieval, Místico, Subterrâneo)
- Escolhe tamanho aleatório (Médio 50%, Grande 50%)

**RoomGenerator.java**
- Cria salas individuais
- Gera paredes, teto, chão
- Cria corredores conectando salas
- Limpa áreas para construção

**StructureBuilder.java**
- Constrói elementos decorativos
- Pilares, altares, pontes
- Torres, escadas
- Decorações específicas

---

### 🏰 Tipos de Dungeons (types/)

#### MedievalDungeon.java
**Características:**
- Materiais: Stone Bricks, Smooth Stone, Mossy Stone
- Layout: Salas lineares conectadas
- Decoração: Tochas, pilares, blocos musgosos
- Boss: Cavaleiro das Trevas
- Tamanho Médio: 15x15, 4 salas
- Tamanho Grande: 20x20, 7 salas

#### MysticDungeon.java
**Características:**
- Materiais: Dark Prismarine, Obsidian, Prismarine
- Layout: Salas em círculo ao redor de torre
- Decoração: Sea Lanterns, cristais, End Stone
- Boss: Feiticeiro Ancestre
- Tamanho Médio: 16x16, 5 salas
- Tamanho Grande: 22x22, 8 salas + torre

#### UndergroundDungeon.java
**Características:**
- Materiais: Deepslate, Cobbled Deepslate
- Layout: Túneis irregulares, cavernas naturais
- Decoração: Estalactites, teias, minérios
- Boss: Golem das Cavernas
- Tamanho Médio: 14x14, 5 cavernas
- Tamanho Grande: 18x18, 9 cavernas

---

### 💎 Sistema de Conteúdo (content/)

#### LootManager.java
**Responsabilidades:**
- Colocar baús com loot
- Colocar spawners de mobs
- 4 tipos de loot tables:
  - Basic (ferro, ouro, comida)
  - Medieval (armas, armaduras)
  - Mystic (itens mágicos, ender pearls)
  - Mining (minérios, ferramentas)
  - Boss Reward (diamante, netherite, totems)

#### TrapManager.java
**Tipos de Armadilhas:**
- Arrow Trap (dispenser + pressure plate)
- TNT Trap (tnt + redstone)
- Lava Trap (lava escondida)
- Magic Trap (observer + dispenser)
- Pressure Plate Trap (pistons)

#### PuzzleManager.java
**Tipos de Puzzles:**
- Lever Puzzle (4 alavancas)
- Button Puzzle (sequência de botões)
- Pressure Plate Puzzle (peso)
- Redstone Puzzle (circuito complexo)
- Maze Puzzle (labirinto opcional)

#### BossManager.java
**Bosses Implementados:**

1. **Cavaleiro das Trevas** (Medieval)
   - Tipo: Zombie
   - HP: 200
   - Equipamento: Netherite completo
   - Servos: 2 Skeletons
   
2. **Feiticeiro Ancestre** (Místico)
   - Tipo: Witch
   - HP: 180
   - Efeitos: Regeneration, Speed, Resistance
   - Servos: 3 Endermans, 4 Vexes
   
3. **Golem das Cavernas** (Subterrâneo)
   - Tipo: Iron Golem
   - HP: 250
   - Efeitos: Resistance II, Knockback Immunity
   - Servos: 4 Spiders, 3 Zombies

---

### 🎮 Comandos e Listeners

#### DungeonCommand.java
Comandos administrativos:
- `/dungeon create` - Força geração
- `/dungeon list` - Lista dungeons
- `/dungeon info` - Informações
- `/dungeon reload` - Recarrega config

#### ChunkListener.java
- Escuta evento de carregamento de chunk
- Verifica se deve gerar dungeon
- Executa geração assíncrona (delay 1s)
- Apenas no Overworld

---

## 🔧 Tecnologias Utilizadas

### Core
- **Java:** 21
- **Spigot API:** 1.21.1-R0.1-SNAPSHOT
- **Maven:** Build e gerenciamento de dependências

### APIs do Minecraft
- Bukkit/Spigot API
- World Generation API
- Entity API
- Inventory API
- Command API
- Event API

---

## 📊 Estatísticas do Código

### Arquivos Java
- **Total:** 13 classes
- **Main Plugin:** 1
- **Generators:** 3
- **Dungeon Types:** 3
- **Content Managers:** 4
- **Commands:** 1
- **Listeners:** 1

### Linhas de Código (aprox.)
- **DungeonPlugin:** ~50 linhas
- **DungeonGenerator:** ~120 linhas
- **RoomGenerator:** ~150 linhas
- **StructureBuilder:** ~130 linhas
- **MedievalDungeon:** ~180 linhas
- **MysticDungeon:** ~200 linhas
- **UndergroundDungeon:** ~250 linhas
- **LootManager:** ~200 linhas
- **TrapManager:** ~150 linhas
- **PuzzleManager:** ~180 linhas
- **BossManager:** ~250 linhas
- **DungeonCommand:** ~80 linhas
- **ChunkListener:** ~40 linhas

**Total:** ~2000+ linhas de código Java

---

## 🎯 Fluxo de Execução

### 1. Inicialização
```
Server Start
    ↓
DungeonPlugin.onEnable()
    ↓
├── Load Config
├── Initialize DungeonGenerator
├── Register ChunkListener
└── Register DungeonCommand
```

### 2. Geração Natural
```
Player Explores
    ↓
Chunk Loads
    ↓
ChunkListener.onChunkLoad()
    ↓
DungeonGenerator.shouldGenerateDungeon()
    ↓ (1 in 700 chance)
DungeonGenerator.generateDungeon()
    ↓
├── Find suitable location (Y=10-50)
├── Choose random type (Medieval/Mystic/Underground)
├── Choose random size (Medium/Large)
└── Generate dungeon
    ↓
    ├── Create rooms
    ├── Add content (chests, spawners)
    ├── Add traps and puzzles
    └── Spawn boss
```

### 3. Geração Manual
```
Admin uses /dungeon create
    ↓
DungeonCommand.onCommand()
    ↓
DungeonGenerator.generateDungeon()
    ↓
[Same as natural generation]
```

---

## 🛠️ Customização

### Adicionar Novo Tipo de Dungeon

1. Crie nova classe em `types/`:
```java
public class CustomDungeon {
    public void generate(Location start, boolean isLarge) {
        // Sua implementação
    }
}
```

2. Adicione ao `DungeonGenerator.java`:
```java
case 3:
    new CustomDungeon(plugin).generate(dungeonLoc, isLarge);
    break;
```

### Adicionar Novo Boss

Edite `BossManager.java`:
```java
public void spawnCustomBoss(Location loc) {
    // Sua implementação
}
```

### Modificar Frequência

Edite `config.yml`:
```yaml
generation:
  rarity: 100  # Mais frequente
```

---

## 🔐 Permissões

| Permissão | Descrição | Padrão |
|-----------|-----------|--------|
| `dungeon.admin` | Todos os comandos | OP |

---

## 📝 Notas Técnicas

### Performance
- Geração assíncrona com delay
- Evita gerar em mesma localização
- Otimizado para grandes estruturas

### Compatibilidade
- Funciona com plugins de proteção
- Respeita world borders
- Apenas Overworld (configurable)

### Limitações Atuais
- Não salva estruturas (regeneram no reload do chunk)
- Boss não tem mecânicas customizadas complexas
- Loot é fixo (não procedural)

---

**Última Atualização:** v1.0.0  
**Desenvolvido para:** Minecraft 1.21.10
