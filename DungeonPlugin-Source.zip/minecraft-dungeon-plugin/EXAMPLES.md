# 📖 Exemplos de Uso - DungeonPlugin

## 🎮 Cenários de Uso

### 1. Servidor de Sobrevivência Vanilla+

**Configuração Recomendada:**
```yaml
generation:
  rarity: 500  # Dungeons raras mas não impossíveis
  
dungeon-types:
  medieval: { enabled: true, weight: 40 }
  mystic: { enabled: true, weight: 30 }
  underground: { enabled: true, weight: 30 }

rewards:
  loot-multiplier: 1.2  # Um pouco mais de recompensa
  boss-guaranteed-rare: true
```

**Por quê?**
- Dungeons raras mantêm o valor
- Medieval mais comum (tema vanilla)
- Loot ligeiramente aumentado para compensar dificuldade

---

### 2. Servidor RPG/Adventure

**Configuração Recomendada:**
```yaml
generation:
  rarity: 300  # Mais dungeons para explorar
  
dungeon-types:
  medieval: { enabled: true, weight: 25 }
  mystic: { enabled: true, weight: 50 }  # Tema mágico
  underground: { enabled: true, weight: 25 }

sizes:
  medium: { chance: 30 }
  large: { chance: 70 }  # Dungeons maiores

rewards:
  loot-multiplier: 1.5
  epic-item-chance: 25
```

**Por quê?**
- Mais dungeons para aventuras
- Foco em dungeons místicas (tema RPG)
- Dungeons maiores e mais desafiadoras
- Mais loot para progressão RPG

---

### 3. Servidor PvE Hardcore

**Configuração Recomendada:**
```yaml
generation:
  rarity: 800  # Muito raras = muito valiosas
  
dungeon-types:
  medieval: { enabled: true, weight: 20 }
  mystic: { enabled: true, weight: 20 }
  underground: { enabled: true, weight: 60 }  # Mais perigosas

sizes:
  medium: { chance: 20 }
  large: { chance: 80 }  # Máximo desafio

rewards:
  loot-multiplier: 2.0  # Dobro de recompensa
  boss-guaranteed-rare: true
  epic-item-chance: 40
```

**Por quê?**
- Dungeons extremamente raras
- Foco em dungeons subterrâneas (mais difíceis)
- Grandes dungeons para grupos
- Recompensas massivas para risco alto

---

### 4. Servidor Criativo/Teste

**Configuração Recomendada:**
```yaml
generation:
  rarity: 50  # Muitas dungeons para testar
  
dungeon-types:
  medieval: { enabled: true, weight: 33 }
  mystic: { enabled: true, weight: 33 }
  underground: { enabled: true, weight: 34 }

sizes:
  medium: { chance: 50 }
  large: { chance: 50 }
```

**Comandos Úteis:**
```
/dungeon create    # Gerar onde você está
/dungeon list      # Ver todas geradas
/dungeon info      # Estatísticas
```

---

## 🎯 Casos de Uso Específicos

### Evento de Exploração

```bash
# 1. Aumentar temporariamente a frequência
# Editar config.yml:
generation:
  rarity: 100

# 2. Recarregar
/dungeon reload

# 3. Jogadores exploram por 2 horas

# 4. Restaurar configuração normal
generation:
  rarity: 700

# 5. Recarregar novamente
/dungeon reload
```

---

### Boss Rush Event

```bash
# Gerar múltiplas dungeons em área específica
/tp 1000 50 1000
/dungeon create

/tp 1200 50 1000
/dungeon create

/tp 1000 50 1200
/dungeon create

# Jogadores competem para limpar todas!
```

---

### Testando Novos Bosses

```bash
# 1. Criar dungeon de teste
/dungeon create

# 2. Verificar logs
/dungeon info

# 3. Ajustar dificuldade no código se necessário
# Editar BossManager.java
# Recompilar com ./build.sh
```

---

## 📊 Exemplos de Progressão

### Jogador Solo

**Nível Iniciante (Ferro):**
- Explorar dungeons Medieval Médias
- Evitar bosses inicialmente
- Focar em loot de baús normais

**Nível Intermediário (Diamante):**
- Enfrentar bosses de dungeons Médias
- Explorar dungeons Místicas
- Completar puzzles para loot extra

**Nível Avançado (Netherite):**
- Dungeons Grandes de qualquer tipo
- Boss rush em múltiplas dungeons
- Coletar Nether Stars e Totems

---

### Grupo (2-4 Jogadores)

**Estratégia Eficiente:**
```
Tanque (Armadura Pesada) 
    ↓
  Boss
    ↑
Arqueiro (Dano de Longe)
    ↑
Suporte (Cura/Buffs)
```

**Divisão de Tarefas:**
- Jogador 1: Enfrenta boss
- Jogador 2: Elimina servos
- Jogador 3: Desarma armadilhas
- Jogador 4: Coleta loot

---

## 🏆 Desafios Comunitários

### 1. Speedrun de Dungeon
```
Objetivo: Limpar dungeon no menor tempo possível
Regras:
- Sem preparação prévia
- Boss deve ser derrotado
- Todo loot coletado
```

### 2. Dungeon Hardcore
```
Objetivo: Completar sem morrer
Regras:
- Uma vida apenas
- Sem regeneração natural
- Sem teleporte
```

### 3. Minimalista
```
Objetivo: Completar com equipamento mínimo
Regras:
- Apenas armadura de ferro
- Espada de ferro
- Sem poções
```

### 4. Pacifista
```
Objetivo: Coletar loot sem matar nada
Regras:
- Não pode atacar mobs
- Pode usar armadilhas contra eles
- Stealth é permitido
```

---

## 💡 Dicas Avançadas

### Farming Eficiente

**Melhor Rota:**
1. Encontrar dungeon Medieval
2. Limpar sala por sala
3. Salvar boss por último
4. Coletar todo loot
5. Marcar coordenadas
6. Retornar após respawn de mobs

**Melhores Dungeons para Farm:**
- **Medieval:** Loot consistente, baixo risco
- **Mística:** Itens mágicos valiosos
- **Subterrânea:** Minérios extras

---

### Preparação Ideal

**Kit Básico:**
```
✅ Armadura completa (Ferro+)
✅ Espada + Arco
✅ 64 Flechas
✅ 32 Tochas
✅ 64 Blocos (terra/cobblestone)
✅ 16 Comida
✅ 1 Water Bucket
✅ 1 Lava Bucket (opcional)
✅ Poção de Cura
✅ Ender Pearls (fuga emergência)
```

**Kit Avançado:**
```
✅ Armadura Netherite
✅ Espada Netherite (Sharpness V)
✅ Arco (Power V, Infinity)
✅ Golden Apples (5+)
✅ Totem of Undying
✅ Poções (Força, Velocidade, Resistência ao Fogo)
✅ Ender Chest (guardar loot importante)
```

---

### Estratégias por Boss

#### Cavaleiro das Trevas (Medieval)
```
Estratégia:
1. Eliminar Guardians primeiro (arqueiros)
2. Kite o knight ao redor dos pilares
3. Usar arco quando possível
4. Atenção à armadura pesada dele

Fraquezas:
- Lento
- Sem ataques de longa distância
- Vulnerável a knockback (pouco)
```

#### Feiticeiro Ancestre (Místico)
```
Estratégia:
1. Eliminar Vexes primeiro (voam)
2. Evitar Endermans (não olhe diretamente)
3. Priorize o Sorcerer quando possível
4. Use água contra Endermans

Fraquezas:
- Poções podem ser esquivadas
- Regeneração lenta
- Servos são fracos individualmente
```

#### Golem das Cavernas (Subterrâneo)
```
Estratégia:
1. Fique em plataformas acima da lava
2. Elimine Spiders montadas primeiro
3. Use arco - Golem é lento
4. Evite confronto direto

Fraquezas:
- Muito lento
- Não pode voar/pular
- Vulnerável a dano de queda
- Pode ser kited indefinidamente
```

---

## 🎥 Gravação de Conteúdo

### Para YouTubers/Streamers

**Ideias de Vídeo:**
1. "Primeira vez em Dungeon Mística!"
2. "Boss Rush - 10 Dungeons Seguidas"
3. "Dungeon com Equipamento Iniciante"
4. "Ranking das Melhores Dungeons"
5. "Tutorial Completo de Sobrevivência"

**Comandos Úteis para Gravação:**
```bash
/dungeon create    # Criar dungeon on-demand
/gamemode creative # Explorar estrutura antes
/gamemode survival # Voltar para desafio real
```

**Dicas:**
- Mostre diferentes tipos (variedade)
- Explique mecânicas dos bosses
- Compare loot obtido
- Faça desafios criativos

---

## 🔧 Troubleshooting em Jogo

### "Não consigo vencer o boss"

**Soluções:**
```
1. Traga amigos (multiplayer)
2. Melhore equipamento
3. Use poções de buff
4. Pratique com bosses mais fracos primeiro
5. Aprenda os padrões de ataque
```

### "Perdi muito loot quando morri"

**Prevenção:**
```
1. Leve Ender Chest
2. Guarde itens valiosos antes do boss
3. Use Totem of Undying
4. Marque coordenadas da dungeon
5. Configure /home na entrada
```

### "Armadilha me matou"

**Prevenção:**
```
1. Sempre leve tochas (iluminação)
2. Ande devagar em salas novas
3. Procure redstone/pressure plates
4. Quebre armadilhas antes de passar
5. Tenha poção de cura rápida
```

---

## 📈 Análise de Custo-Benefício

### Tempo vs Recompensa

**Dungeon Medieval Média:**
- Tempo: 15-20 minutos
- Recompensa: ⭐⭐⭐ (Boa)
- Dificuldade: ⭐⭐ (Média)
- **Melhor para:** Farm eficiente

**Dungeon Mística Grande:**
- Tempo: 30-40 minutos
- Recompensa: ⭐⭐⭐⭐⭐ (Excelente)
- Dificuldade: ⭐⭐⭐⭐ (Difícil)
- **Melhor para:** Loot mágico raro

**Dungeon Subterrânea Grande:**
- Tempo: 35-45 minutos
- Recompensa: ⭐⭐⭐⭐ (Muito Boa)
- Dificuldade: ⭐⭐⭐⭐⭐ (Muito Difícil)
- **Melhor para:** Desafio extremo

---

## 🎊 Celebração de Conquistas

### Marcos Importantes

```
✅ Primeira Dungeon Descoberta
✅ Primeiro Boss Derrotado
✅ 10 Dungeons Limpas
✅ Boss de Cada Tipo Derrotado
✅ Dungeon Grande Solo
✅ Boss Sem Tomar Dano
✅ 100 Dungeons Exploradas
✅ Coleção Completa de Loot de Boss
```

**Recompensas Sugeridas:**
- Título no servidor
- Kit especial
- Acesso a área VIP
- Destaque no Discord

---

**Divirta-se explorando! 🎮⚔️🏆**
