# 🚀 Guia de Início Rápido - DungeonPlugin

## ⚡ Instalação Rápida (3 passos)

### 1️⃣ Compilar o Plugin

```bash
cd /app/minecraft-dungeon-plugin
./build.sh
```

Ou manualmente com Maven:
```bash
mvn clean package
```

### 2️⃣ Instalar no Servidor

```bash
# Copie o JAR para a pasta plugins do seu servidor
cp target/DungeonPlugin-1.0.0.jar /caminho/para/seu/servidor/plugins/

# Reinicie o servidor
```

### 3️⃣ Jogar!

As dungeons começarão a gerar automaticamente enquanto você explora o mundo!

---

## 🎮 Primeiros Passos

### Comandos Essenciais

```
/dungeon create    - Gera uma dungeon imediatamente na sua localização
/dungeon info      - Ver estatísticas do plugin
/dungeon list      - Listar dungeons geradas
```

### Encontrar Dungeons

🔍 **Naturalmente:**
- Explore o Overworld normalmente
- Dungeons geram raramente (1 a cada 700 chunks)
- Ficam underground entre Y=10 e Y=50

⚡ **Forçar Geração:**
```
/dungeon create
```

---

## ⚙️ Configuração Rápida

Edite `plugins/DungeonPlugin/config.yml`:

### Aumentar Frequência
```yaml
generation:
  rarity: 200  # Mais comum (padrão: 700)
```

### Desabilitar um Tipo
```yaml
dungeon-types:
  mystic:
    enabled: false  # Desabilita dungeons místicas
```

### Mais Loot
```yaml
rewards:
  loot-multiplier: 2.0  # Dobro de loot (padrão: 1.0)
```

Depois de editar: `/dungeon reload`

---

## 🏆 Dicas de Sobrevivência

### ⚔️ Preparação Recomendada
- Armadura de Ferro/Diamante completa
- Espada e Arco encantados
- Comida (Golden Apples recomendado)
- Tochas e Blocos
- Poções de cura

### 🎯 Estratégias por Tipo

**Medieval 🏰**
- Cuidado com esqueletos e armadilhas de flechas
- Boss tem armadura pesada - use arco
- Procure alavancas para puzzles

**Místico 🔮**
- Endermans teleportam - tenha água
- Boss invoca servos - elimine-os primeiro
- Iluminação natural (Sea Lanterns)

**Subterrâneo ⛏️**
- Risco de lava - poções de resistência ao fogo
- Aranhas montadas são perigosas
- Mine os minérios para recursos extras

---

## 📊 Estatísticas

### Tamanhos
- **Médio:** 15-30 blocos, 4-5 salas
- **Grande:** 40-60 blocos, 7-9 salas

### Conteúdo Garantido
- ✅ 3-8 Baús com loot
- ✅ 2-4 Spawners
- ✅ 3-6 Armadilhas
- ✅ 1-3 Puzzles
- ✅ 1 Boss + Servos

### Recompensas Médias (Boss)
- 🗡️ Espada/Armadura Diamante encantada
- 💎 10-25 Diamantes
- 💚 15-35 Esmeraldas
- 🍎 1-2 Enchanted Golden Apples
- ⭐ 1 Nether Star
- 🧙 32 Garrafas de XP

---

## 🐛 Problemas Comuns

### "Não encontro dungeons"
➡️ Use `/dungeon create` para testar
➡️ Reduza `rarity` no config.yml

### "Boss muito difícil"
➡️ Traga amigos!
➡️ Use equipamento melhor
➡️ Elimine servos primeiro

### "Erro ao compilar"
➡️ Verifique se tem Java 21+
➡️ Verifique se tem Maven instalado
➡️ Veja os logs de erro

---

## 📞 Suporte

**Comandos de Debug:**
```
/dungeon info    - Ver informações
/dungeon list    - Ver dungeons geradas
```

**Logs:**
```
tail -f logs/latest.log | grep Dungeon
```

---

## 🎉 Divirta-se!

Boa sorte explorando as dungeons! 

Cada uma é única e oferece desafios diferentes. Reúna seus amigos, prepare seu equipamento e parta para a aventura! 🗡️🛡️

---

**Versão:** 1.0.0  
**Suporte:** Minecraft 1.21.10  
**Criado com:** Spigot API + Java 21
