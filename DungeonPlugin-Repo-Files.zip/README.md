# DungeonPlugin

Este repositório contém a configuração necessária para compilar automaticamente seu plugin usando GitHub Actions.

## 📦 Compilação Automática

1. Vá até a aba **Actions**
2. Execute o workflow **Build DungeonPlugin**
3. Baixe o arquivo `.jar` em **Artifacts**

## 📂 Arquivos incluídos

- `.github/workflows/build.yml` – Workflow do GitHub Actions
- `pom.xml` – Arquivo Maven do projeto (extraído automaticamente)

Faça upload também da pasta `src/` do seu projeto.
